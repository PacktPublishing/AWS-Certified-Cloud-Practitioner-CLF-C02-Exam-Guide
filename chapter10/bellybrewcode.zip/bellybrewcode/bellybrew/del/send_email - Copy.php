<?php
require 'aws.phar';
use Aws\Ses\SesClient;

// AWS credentials
$aws_access_key = 'AKIA5PNI2ND6OOGJ4QB2';
$aws_secret_key = 'wdQWyl7Gtq8BWYQcr7bW3ibn/kxbMZVJRCr4vwIt';

// S3 Bucket and Object details
$bucket = 'maneesha-redshift-data';  // Your S3 bucket
$keyName = 'recipe_book/Recipe-Book.pdf';  // The S3 file path
$region = 'us-east-2';  // AWS region


header('Content-Type: application/json');

// 1. Get email from frontend
$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'] ?? '';
echo "-----email----".$email;

// 2. Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['error' => 'Invalid email']);
    exit;
}

// 3. Configure SES
$ses = new SesClient([
    'version' => 'latest',
    'region'  => $region,
    'credentials' => [
        'key'    => $aws_access_key,
        'secret' => $aws_secret_key,
    ],
]);

// 4. Send email
try {
    $result = $ses->sendEmail([
        'Source' => 'skagrawal10@gmail.com', // SES-verified email
        'Destination' => ['ToAddresses' => [$email]],
        'Message' => [
            'Subject' => ['Data' => 'Hello from BellyBrew'],
            'Body' => ['Text' => ['Data' => 'Hi there! Thanks for your submission.']],
        ],
    ]);
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>