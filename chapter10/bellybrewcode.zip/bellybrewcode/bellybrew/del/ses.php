<?php

// Include the AWS SDK using the .phar file
require_once 'aws.phar';  // Update this path to where you placed the aws.phar file

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

// AWS credentials
$aws_access_key = 'AKIA5PNI2ND6OOGJ4QB2';
$aws_secret_key = 'wdQWyl7Gtq8BWYQcr7bW3ibn/kxbMZVJRCr4vwIt';


// S3 Bucket and Object details
$bucket = 'maneesha-redshift-data';  // Your S3 bucket
$keyName = 'recipe_book/Recipe-Book.pdf';  // The S3 file path
$region = 'us-east-2';  // AWS region
$expires = 3600;  // URL expiration time in seconds (1 hour)

try {
    // Create an S3 client
    $s3Client = new S3Client([
        'region' => $region,
        'version' => 'latest',
        'credentials' => [
            'key'    => $aws_access_key,
            'secret' => $aws_secret_key,
        ]
    ]);

    // Generate the pre-signed URL for the object
    $cmd = $s3Client->getCommand('GetObject', [
        'Bucket' => $bucket,
        'Key'    => $keyName,
    ]);

    // Generate a pre-signed URL that expires in 1 hour
    $request = $s3Client->createPresignedRequest($cmd, '+' . $expires . ' seconds');

    // Get the actual pre-signed URL
    echo $presignedUrl = (string) $request->getUri();
	echo'<br>';echo'<br>';echo'<br>';


    // Output the pre-signed URL
    echo json_encode(['url' => $presignedUrl]);

} catch (AwsException $e) {
    // Catch and display any errors
    echo json_encode(['error' => $e->getMessage()]);
}
