<?php
$responseMessage = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate email
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email address.");
        }

        // Load AWS SDK
        require 'aws.phar';

        // AWS config
		
		$awsConfig = [
            'region'  => 'eu-west-2',
            'version' => 'latest'
        ];

        // 1. Store data in DB
         $insertId = storeFormDataInDatabase($_POST, $awsConfig);

        // 2. Send recipe book email
        $emailResult = sendRecipeBookEmail($email, $awsConfig);

        // 3. Build response message
        if ($insertId) {
            $responseMessage .= "Data saved successfully. ID: $insertId. ";
        } else {
            $responseMessage .= "Failed to save form data. ";
        }

        $responseMessage .= $emailResult['success']
            ? "Email sent successfully (Message ID: {$emailResult['MessageId']})."
            : "Email failed: {$emailResult['error']}";

    } catch (Exception $e) {
        $responseMessage = "Error: " . $e->getMessage();
    }

    showAlertMessage($responseMessage);
}

/**
 * Show JavaScript alert message.
 */
function showAlertMessage($message) {
    if (!empty($message)) {
        $escapedMessage = addslashes($message);
        echo <<<HTML
        <script type="text/javascript">
            alert("$escapedMessage");
            window.scrollTo(0, 0);
        </script>
HTML;
    }
}

/**
 * Store form data in database and return insert ID or false.
 */
 


function storeFormDataInDatabase($data, $awsConfig) {
	
	 // Load the Secrets Manager client
    $secretsClient = new Aws\SecretsManager\SecretsManagerClient($awsConfig);

    try {
        // Fetch secret by name
        $result = $secretsClient->getSecretValue([
            'SecretId' => '[PROVIDE SECRET NAME HERE]'
        ]);

        // Decode JSON secret string
        $secret = json_decode($result['SecretString'], true);

        // Now extract DB credentials
        $dbHost = $secret['host'] ?? '';
        $dbUser = $secret['username'] ?? '';
        $dbPass = $secret['password'] ?? '';
        $dbName = $secret['dbname'] ?? '';

        if (!$dbHost || !$dbUser || !$dbPass || !$dbName) {
            throw new Exception("Database credentials incomplete in Secrets Manager.");
        }

        // Connect using PDO
        $pdo = new PDO(
            "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4",
            $dbUser,
            $dbPass,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );

        // Create table if it doesn't exist
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS form_recipebook (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                address TEXT NOT NULL,
                town VARCHAR(100) NOT NULL,
                city VARCHAR(100) NOT NULL,
                postcode VARCHAR(50) NOT NULL,
                country VARCHAR(100) NOT NULL,
                date DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $stmt = $pdo->prepare("
            INSERT INTO form_recipebook 
                (name, email, address, town, city, postcode, country, date)
            VALUES 
                (:name, :email, :address, :town, :city, :postcode, :country, NOW())
        ");

        $stmt->execute([
            ':name'     => trim($data['name'] ?? ''),
            ':email'    => trim($data['email'] ?? ''),
            ':address'  => trim($data['address'] ?? ''),
            ':town'     => trim($data['town'] ?? ''),
            ':city'     => trim($data['city'] ?? ''),
            ':postcode' => trim($data['postcode'] ?? ''),
            ':country'  => trim($data['country'] ?? '')
        ]);

        return $pdo->lastInsertId();

    } catch (Aws\Exception\AwsException $e) {
        error_log("AWS Secrets Manager Error: " . $e->getAwsErrorMessage());
        return false;
    } catch (PDOException $e) {
        error_log("DB Error: " . $e->getMessage());
        return false;
    } catch (Exception $e) {
        error_log("General Error: " . $e->getMessage());
        return false;
    }
   
}

/**
 * Sends the recipe book email via AWS SES with a presigned S3 download link.
 */
function sendRecipeBookEmail($email, $awsConfig) {
    try {
        $s3 = new Aws\S3\S3Client($awsConfig);

        $cmd = $s3->getCommand('GetObject', [
            'Bucket' => '[PROVIDE YOUR RECIPE EBOOK BUCKET NAME]',
            'Key'    => '[PROVIDE YOUR eBOOK path, e.g, recipe-book/ebook.pdf]'
        ]);

        $presignedUrl = (string) $s3->createPresignedRequest($cmd, '+1 hour')->getUri();

        $ses = new Aws\Ses\SesClient($awsConfig);

        $result = $ses->sendEmail([
            'Source' => '[PROVIDE YOUR VERIFIED EMAIL ADDRESS]',
            'Destination' => ['ToAddresses' => [$email]],
            'Message' => [
                'Subject' => ['Data' => 'Your Recipe Book'],
                'Body' => [
                    'Text' => ['Data' => "Download your recipe book: $presignedUrl"],
                    'Html' => ['Data' => "<p>Thank you! Click below to download your recipe book:</p><p><a href='$presignedUrl'>Download Recipe Book</a></p>"]
                ]
            ]
        ]);

        return [
            'success' => true,
            'MessageId' => $result->get('MessageId')
        ];

    } catch (Aws\Exception\AwsException $e) {
        error_log("AWS SES Error: " . $e->getAwsErrorMessage());
        return ['success' => false, 'error' => $e->getAwsErrorMessage()];
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}
?>



<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>BellyBrew</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/reset.css" rel="stylesheet" type="text/css">
	<link href="css/veg-styles.css" rel="stylesheet">
	<link href="css/veg-responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->
	<script src="js/jquery-3.4.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.plugin.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>

	<link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">

	<style type="text/css">
		#dish_of_day {
			color: #000;
			
    left: 50%;
    position: absolute;
    top: 41px;
    width: 621px;
    line-height: 40px;
    margin-left: 44px;
		}
		#mc-embedded-subscribe:hover{
			background-color: #e83e8c;;
			
		}
		.carousel-control-next-icon, .carousel-control-prev{
			filter: invert(1) grayscale(1) brightness(0) sepia(1) hue-rotate(180deg);
            
		}
		.carousel-control-next-icon{
			margin-left: 40px;
		}
		.carousel-control-prev{
			padding-right: 60px !important;
		}
#dish_of_day1 {
			color: #000;
			margin: 20px;
    left: 50%;
    position: absolute;
    top: 41px;
    width: 621px;
    line-height: 40px;
    margin-left: 44px;
		}

		#dish_of_day h4,
		#dish_of_day h5 {
			margin: 10px;
		}
		#mc_embed_signup {
			background: #fff;
			clear: left;
			font: 14px Helvetica, Arial, sans-serif;
		}

		#mc_embed_signup label.error {
			margin-left: 0px !important;
			color: indianred;
		}

		.coming-soon .desc {
			padding: 60px 0 0 140px !important;
		}
.wrapper-8 {
    float: left;
    height: 460px;
    margin: 0 35px 0 0;
    position: relative;
    width: 820px;
}
.text-10 {
    float: left;
    margin: 74px 0 0;
    width: 532px;
    color: #666666;
    font-size: 2.5rem;
}
.text-style-2 {
    font-weight: 600;
    line-height: 70.8px;
}
.text-style-3 {
    font-weight: 600;
    line-height: 47.8px;
}
.text-style-4 {
    line-height: 53.8px;
}
.l-constrained {
    margin: 67px auto 0;
    padding: 0 256px;
    position: relative;
    width: 1920px;
}
section.form.pb01 {
    /* float: left; */
   margin-top: 125px;
    width: 527px;
    color: #666666;
    font-size: 2.5rem
font-weight: 600;
}

{box-sizing: border-box}
body {font-family:"Montserrat", sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #1d1b1b;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

.modern-form-container {
    background: linear-gradient(135deg, #ffffff00 0%, #ffffff00 100%);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    position: relative;
    overflow: hidden;
}

.modern-form-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, transparent 50%, rgba(255,255,255,0.1) 100%);
    pointer-events: none;
}

/* Form Title and Subtitle */
.modern-form-title {
    color: rgb(29, 27, 27);
    font-family: 'Montserrat', sans-serif;
    font-size: 24px;
    font-weight: 700;
    text-align: center;
    margin-bottom: 8px;
}

.modern-form-subtitle {
    color: rgba(39, 37, 37, 0.9);
    font-family: 'Montserrat', sans-serif;
    font-size: 14px;
    text-align: center;
    margin-bottom: 25px;
    line-height: 1.4;
}

/* Form Layout */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 20px;
}

.form-row.full-width {
    grid-template-columns: 1fr;
}

.form-row .modern-form-group {
    margin-bottom: 0;
}

/* Form Groups and Inputs */
.modern-form-group {
    position: relative;
    margin-bottom: 20px;
}

.modern-form-input {
    width: 100%;
    padding: 12px 15px 12px 40px;
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 12px;
    background: rgba(255,255,255,0.1);
    color: rgb(35, 33, 33);
    font-size: 14px;
    font-family: 'Montserrat', sans-serif;
    backdrop-filter: blur(10px);
    transition: all 0.3s ease;
    box-sizing: border-box;
    height: 45px;
}

.modern-form-input::placeholder {
    color: rgba(24, 24, 24, 0.7);
    font-weight: 500;
    font-size: 13px;
}

.modern-form-input:focus {
    outline: none;
    border-color: rgba(255,255,255,0.5);
    background: rgba(255,255,255,0.15);
    transform: translateY(-1px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}

/* Select Dropdown Styling */
.modern-form-input select,
select.modern-form-input {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6,9 12,15 18,9'%3e%3c/polyline%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 15px center;
    background-size: 16px;
    padding-right: 45px;
}

select.modern-form-input option {
    background: #333;
    color: rgb(36, 31, 31);
    padding: 10px;
}

/* Form Icons */
.modern-form-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(49, 47, 47, 0.7);
    font-size: 16px;
    z-index: 2;
}

/* Submit Button */
.modern-submit-btn {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #ff6b6b, #ee5a24);
    border: none;
    border-radius: 12px;
    color: white;
    font-size: 16px;
    font-weight: 700;
    font-family: 'Montserrat', sans-serif;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 6px 15px rgba(238, 90, 36, 0.3);
    position: relative;
    overflow: hidden;
    height: 50px;
}

.modern-submit-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s ease;
}

.modern-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 25px rgba(238, 90, 36, 0.4);
}

.modern-submit-btn:hover::before {
    left: 100%;
}

.modern-submit-btn:active {
    transform: translateY(-1px);
}

/* Response and Error Messages */
.modern-response {
    margin-top: 15px;
    padding: 12px;
    border-radius: 8px;
    background: rgba(255,255,255,0.1);
    color: white;
    text-align: center;
    font-family: 'Montserrat', sans-serif;
    font-weight: 500;
    font-size: 14px;
    backdrop-filter: blur(10px);
    display: none;
}

.error-message {
    color: #ff6b6b;
    font-size: 12px;
    margin-top: 4px;
    font-family: 'Montserrat', sans-serif;
    display: none;
    margin-left: 2px;
}

/* Floating Decorative Shapes */
.floating-shapes {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    pointer-events: none;
    overflow: hidden;
}

.shape {
    position: absolute;
    background: rgba(255,255,255,0.1);
    border-radius: 50%;
    animation: float 6s ease-in-out infinite;
}

.shape:nth-child(1) {
    width: 60px;
    height: 60px;
    top: 15%;
    left: 8%;
    animation-delay: -2s;
}

.shape:nth-child(2) {
    width: 40px;
    height: 40px;
    top: 65%;
    right: 12%;
    animation-delay: -4s;
}

.shape:nth-child(3) {
    width: 30px;
    height: 30px;
    bottom: 25%;
    left: 15%;
    animation-delay: -1s;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-15px) rotate(180deg); }
}

/* Responsive Design */
@media (max-width: 768px) {
    .modern-form-container {
        padding: 25px 20px;
        margin: 10px;
    }
    
    .modern-form-title {
        font-size: 22px;
    }
    
    .modern-form-subtitle {
        font-size: 13px;
    }
    
    .form-row {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .modern-form-input {
        padding: 10px 12px 10px 35px;
        font-size: 13px;
        height: 42px;
    }
    
    .modern-form-icon {
        left: 12px;
        font-size: 14px;
    }
    
    .modern-submit-btn {
        padding: 12px;
        font-size: 14px;
        height: 45px;
    }
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
	</style>

</head>

<body style="font-family: Montserrat !important;">

<section class="logo">
			<!-- logo-->
			<p class="soon" style="position:absolute;top: 0px; left: 650px; font-size: 50px; font-family:'Montserrat', sans-serif; color: #666666;"></p>

			<section class="container" >
				
<aside class="desc" >

					<figure>
					</figure>

				</aside>

			</section>
		</section><!-- ./logo-->
<section class="coming-soon3">
			<!--coming soon-->
			<section class="container clearfix">
				<aside class="day-zone" id="main">
					<div id="counter1" class="cf clearfix">
						<!-- <div id="defaultCountdown"></div> -->
						<div id="dish_of_day1">
							<p style="
    font-size: 36px;
	font-family:'Montserrat', sans-serif;;
  color: black;
    margin-left: -458px;
    margin-top: -49px;
"><b>Good Gut Health – Solves All Your Health Issues</b>

</p>

						</div>
					</div>
	
				</aside>
				<aside class="desc">
					<figure><img src="images/Logo-BellyBrew.png" alt="" class="img-responsive" style=" 
    margin-left: -100px;
    margin-top: -77px;
"></figure>
				</aside>
			</section>
		</section><!-- ./coming soon-->




	
		
		<section class="coming-soon">
			<!--coming soon-->
			<section class="container clearfix">
				<aside class="day-zone" id="main">
					<div id="counter1" class="cf clearfix">
						<!-- <div id="defaultCountdown"></div> -->
						<div id="dish_of_day">
						
						</div>
					</div>
				</aside>
				<aside class="desc">
				
				</aside>
			</section>
		</section><!-- ./coming soon-->
		<section class="coming-soon1">
			<!--coming soon-->
			<section class="container clearfix">
				<aside class="day-zone" id="main">
					<div id="counter1" class="cf clearfix">
						<!-- <div id="defaultCountdown"></div> -->
						<div id="dish_of_day" style="margin-left: 10px;">
							<h5 style="font-size: 22px; margin-left: 80px; font-family:'Montserrat', sans-serif;;margin-top: 1px;">Coconut kefir is coconut water that has been fermented with kefir grains. Like dairy kefir, it provides fuel for the beneficial bacteria in your gut.</h5>
							<h5 style="font-size: 22px; margin-left: 80px; font-family:'Montserrat', sans-serif;;margin-top: 0px;"> These good bacteria fight potentially harmful bacteria as well as infection. They also help stimulate digestion and boost your immune system</h5>
						</div>
					</div>
				</aside>
				<aside class="desc">
					
				</aside>
			</section>
		</section><!-- ./coming soon-->

		<section class="signup">
			<!-- Signup-->
			<section class="container">
				<section class="signup-in">
					<section class="row">
						<aside class="col-md-7">
<h2 style="color: #1d1b1b; font-family:'Montserrat', sans-serif;">Grab a copy of our delicious gut-friendly recipes and start the new year making one promise to yourself-say it aloud now</h2>
							<p style="color:gray;font-size: 36px;font-family:'Montserrat', sans-serif;text-align: center;">"I will love my gut"</p>
							<div style="height: 237px;margin-top:15px;margin-right: 36px;background-image: url('images/smiley.png');background-repeat: no-repeat;width: 247px;margin-left: 240px;">
							</div>
							</div>
						</aside>


					<aside class="col-md-5">
    <div class="modern-form-container">
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
        
        <h2 class="modern-form-title">Signup for our free</h2>
        <h2 class="modern-form-title">Gut friendly recipe book</h2>
    
        
 <form id="modernForm" method="POST">
    <div class="form-row">
        <div class="modern-form-group">
            <i class="fas fa-user modern-form-icon"></i>
            <input type="text" name="name" id="name" placeholder="Enter your name" class="modern-form-input" required>
        </div>
        
        <div class="modern-form-group">
            <i class="fas fa-envelope modern-form-icon"></i>
            <input type="email" name="email" id="email" placeholder="Enter your email" class="modern-form-input" required>
        </div>
    </div>
    
    <div class="form-row full-width">
        <div class="modern-form-group">
            <i class="fas fa-home modern-form-icon"></i>
            <input type="text" name="address" id="address" placeholder="Enter your address" class="modern-form-input" required>
        </div>
    </div>
    
    <div class="form-row">
        <div class="modern-form-group">
            <i class="fas fa-city modern-form-icon"></i>
            <input type="text" name="town" id="town" placeholder="Enter your town" class="modern-form-input" required>
        </div>
        
        <div class="modern-form-group">
            <i class="fas fa-building modern-form-icon"></i>
            <input type="text" name="city" id="city" placeholder="Enter your city" class="modern-form-input" required>
        </div>
    </div>
    
    <div class="form-row">
        <div class="modern-form-group">
            <i class="fas fa-mail-bulk modern-form-icon"></i>
            <input type="text" name="postcode" id="postcode" placeholder="Enter your post code" class="modern-form-input" required>
        </div>
        
        <div class="modern-form-group">
            <i class="fas fa-globe modern-form-icon"></i>
            <select name="country" id="country" class="modern-form-input" required>
                <option value="">Select your country</option>
                <option value="india">India</option>
                <option value="usa">United States</option>
                <option value="uk">United Kingdom</option>
                <option value="canada">Canada</option>
                <option value="australia">Australia</option>
            </select>
        </div>
    </div>
    
    <button type="submit" class="modern-submit-btn">
        <span>Get My Recipe Book</span>
    </button>

    <?php if (isset($responseMessage)): ?>
        <div class="modern-response"><?= htmlspecialchars($responseMessage) ?></div>
    <?php endif; ?>
</form>

    </div>
</aside>

 						
<div
								style="min-height:350px;margin-top:10px;background-image: url('images/smiley.png'); background-repeat: no-repeat;">
							</div>
					</section>
				</section>
			</section>
		</section><!-- ./Signup-->
		<section class="month" style="display: none;">
			<!--Month-->
			<section class="container" style="display: none;">
				<section class="row">
					<aside class="col-sm-4">
						<section class="month-item">
							<figure><img src="images/green-vegan.png" alt="" class="img-responsive"></figure>
							<h3>Dish of the Month</h3>
							
						</section>
					</aside>
					<aside class="col-sm-4">
						<section class="month-item">
							<figure><img src="images/fresh.png" alt="" class="img-responsive"></figure>
							<h3>For Your Gut!</h3>
							
						</section>
					</aside>
					<aside class="col-sm-4">
						<section class="month-item">
							<figure><img src="images/employee.png" alt="" class="img-responsive"></figure>
							<h3>Employee of the Month</h3>
							
						</section>
					</aside>
				</section>
			</section>
		</section><!-- ./Month-->

<section class="signup1">
			<!-- Signup-->
			<section class="container">
				<section class="signup-in">
					<section class="row">
						<aside class="col-md-7">
							
							<div class="slideshow-container">

								<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
									<div class="carousel-inner"  style="background: none !important;">
									  <div class="carousel-item active">
										<img src="images/slider01.png" class="d-block w-100" alt="...">
									  </div>
									  <div class="carousel-item" style="background: none !important;">
										<img src="images/banner2.png" class="d-block w-100" alt="...">
									  </div>
									  <div class="carousel-item" style="background: none !important;">
										<img src="images/banner3.png" class="d-block w-100" alt="...">
									  </div>
									</div>
									<button class="carousel-control-prev" style="border:none;background:none;" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
									  <span id="next" class="carousel-control-prev-icon" aria-hidden="true"></i></span>
									  <span class="sr-only">Previous</span>
									</button>
									<button class="carousel-control-next" style="border:none;background:none;" type="button" data-target="#carouselExampleIndicators" data-slide="next">
									  <span id="next" class="carousel-control-next-icon" aria-hidden="true"></i></span>
									  <span class="sr-only">Next</span>
									</button>
								  </div>

							
</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>


							</div>
						</aside>
						
							<aside class="col-md-5">
							<section class="form pb01">
								<b><h2 style="color: #1d1b1b; font-size: 40px;font-family:'Montserrat', sans-serif;/* margin-top: -30px; */">Revitalize Your Gut, Delight Your Taste Buds:
</h2></b><h4 style="
    font-size: 30px;
	margin-top: 10px;
    font-family:'Montserrat', sans-serif;
">Nourishing Ready Meals for a Happy, Healthy You, From Our New Authentic Korean Recipes!
</h4>
								
							</section>
						</aside>
						
					</section>
				</section>
			</section>
		</section><!-- ./Signup-->



		
		<footer>
			<!-- Footer-->
			<section class="container">
				<p>Copyright© BellyBrew®</p>
			</section>
		</footer><!-- ./Footer-->
	</section>
</body>

</html>

  