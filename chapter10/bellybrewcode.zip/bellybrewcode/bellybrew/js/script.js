document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('modernForm');
    const response = document.getElementById('form-response');
    const btnText = document.getElementById('btn-text');
    const btnLoading = document.getElementById('btn-loading');
    
    // Check if EmailJS is loaded, if not, wait for it
    function initializeEmailJS() {
        if (typeof emailjs !== 'undefined') {
            console.log('EmailJS loaded successfully');
            emailjs.init("gPWaFxCnY647zQ3NU");
            return true;
        } else {
            console.error('EmailJS not loaded yet');
            return false;
        }
    }
    
    // Wait for EmailJS to load
    let emailJSReady = false;
    const checkEmailJS = setInterval(() => {
        if (initializeEmailJS()) {
            emailJSReady = true;
            clearInterval(checkEmailJS);
        }
    }, 100);
    
    // Timeout after 10 seconds
    setTimeout(() => {
        if (!emailJSReady) {
            clearInterval(checkEmailJS);
            console.error('EmailJS failed to load within 10 seconds');
        }
    }, 10000);
    
    // Form validation functions
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function validatePostcode(postcode) {
        return postcode.trim().length >= 3;
    }
    
    function showError(fieldId, message) {
        const errorElement = document.getElementById(fieldId + '-error');
        const inputElement = document.getElementById(fieldId);
        if (errorElement && inputElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
            inputElement.style.borderColor = '#ff6b6b';
        }
    }
    
    function hideError(fieldId) {
        const errorElement = document.getElementById(fieldId + '-error');
        const inputElement = document.getElementById(fieldId);
        if (errorElement && inputElement) {
            errorElement.style.display = 'none';
            inputElement.style.borderColor = 'rgba(255,255,255,0.2)';
        }
    }
    
    function hideAllErrors() {
        const errorElements = document.querySelectorAll('.error-message');
        const inputElements = document.querySelectorAll('.modern-form-input');
        
        errorElements.forEach(error => error.style.display = 'none');
        inputElements.forEach(input => input.style.borderColor = 'rgba(255,255,255,0.2)');
    }
    
    function validateForm() {
        let isValid = true;
        hideAllErrors();
        
        // Validate name
        const name = document.getElementById('name').value.trim();
        if (name.length < 2) {
            showError('name', 'Name must be at least 2 characters long');
            isValid = false;
        }
        
        // Validate email
        const email = document.getElementById('email').value.trim();
        if (!validateEmail(email)) {
            showError('email', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate address
        const address = document.getElementById('address').value.trim();
        if (address.length < 5) {
            showError('address', 'Please enter a valid address');
            isValid = false;
        }
        
        // Validate town
        const town = document.getElementById('town').value.trim();
        if (town.length < 2) {
            showError('town', 'Please enter a valid town');
            isValid = false;
        }
        
        // Validate city
        const city = document.getElementById('city').value.trim();
        if (city.length < 2) {
            showError('city', 'Please enter a valid city');
            isValid = false;
        }
        
        // Validate postcode
        const postcode = document.getElementById('postcode').value.trim();
        if (!validatePostcode(postcode)) {
            showError('postcode', 'Please enter a valid post code');
            isValid = false;
        }
        
        // Validate country
        const country = document.getElementById('country').value;
        if (!country) {
            showError('country', 'Please select your country');
            isValid = false;
        }
        
        return isValid;
    }
    
    function showResponse(message, isSuccess = true) {
        if (response) {
            response.textContent = message;
            response.style.display = 'block';
            response.style.background = isSuccess ? 
                'rgba(76, 175, 80, 0.2)' : 
                'rgba(244, 67, 54, 0.2)';
            response.style.color = isSuccess ? '#4CAF50' : '#F44336';
            response.style.border = `1px solid ${isSuccess ? '#4CAF50' : '#F44336'}`;
        }
    }
    
    function setLoadingState(loading) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (loading) {
            if (btnText) btnText.style.display = 'none';
            if (btnLoading) btnLoading.style.display = 'inline';
            if (submitBtn) submitBtn.disabled = true;
        } else {
            if (btnText) btnText.style.display = 'inline';
            if (btnLoading) btnLoading.style.display = 'none';
            if (submitBtn) submitBtn.disabled = false;
        }
    }
    
    async function sendEmail(formData) {
        try {
            // Check if EmailJS is ready
            if (!emailJSReady || typeof emailjs === 'undefined') {
                throw new Error('EmailJS is not loaded. Please refresh the page and try again.');
            }
            
            console.log('Attempting to send email with data:', formData);
            
            const templateParams = {
                from_name: formData.name,
                from_email: formData.email,
                address: formData.address,
                town: formData.town,
                city: formData.city,
                postcode: formData.postcode,
                country: formData.country,
                request_date: new Date().toLocaleString(),
                // Add a message field that combines all info
                message: `Name: ${formData.name}\nEmail: ${formData.email}\nAddress: ${formData.address}\nTown: ${formData.town}\nCity: ${formData.city}\nPostcode: ${formData.postcode}\nCountry: ${formData.country}`
            };

            console.log('Template params:', templateParams);

            const result = await emailjs.send(
                'service_27m19ea',         // Your service ID
                'template_wam16dg',        // Your template ID
                templateParams,
                'gPWaFxCnY647zQ3NU'        // Your public key
            );

            console.log("Email sent successfully!", result);
            return result;
        } catch (error) {
            console.error("Failed to send email:", error);
            
            // More detailed error logging
            if (error.status) {
                console.error("Error status:", error.status);
            }
            if (error.text) {
                console.error("Error text:", error.text);
            }
            
            throw error;
        }
    }
    
    // Form submit handler
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            console.log('Form submitted');
            
            if (!validateForm()) {
                console.log('Form validation failed');
                return;
            }
            
            setLoadingState(true);
            
            // Collect form data
            const formData = {
                name: document.getElementById('name').value.trim(),
                email: document.getElementById('email').value.trim(),
                address: document.getElementById('address').value.trim(),
                town: document.getElementById('town').value.trim(),
                city: document.getElementById('city').value.trim(),
                postcode: document.getElementById('postcode').value.trim(),
                country: document.getElementById('country').value
            };
            
            console.log('Form data collected:', formData);
            
            try {
                await sendEmail(formData);
                showResponse('Thank you! Your recipe book request has been sent successfully. Check your email soon!', true);
                form.reset();
            } catch (error) {
                console.error('Error in form submission:', error);
                showResponse('Sorry, there was an error sending your request. Please try again later.', false);
            } finally {
                setLoadingState(false);
            }
        });
    } else {
        console.error('Form element not found');
    }
    
    // Real-time validation on input
    const inputs = form ? form.querySelectorAll('.modern-form-input') : [];
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value.trim()) {
                hideError(this.id);
            }
        });
        
        input.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                this.classList.remove('error');
                hideError(this.id);
            }
        });
    });
    
    // Test EmailJS connection
    console.log('EmailJS object:', typeof emailjs !== 'undefined' ? 'loaded' : 'not loaded');
});